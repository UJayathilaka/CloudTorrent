package com.vonko.cloudtorrent

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Background = Color(0xFF0B1020)
private val Surface = Color(0xFF151D31)
private val Accent = Color(0xFF6C8CFF)
private val Muted = Color(0xFF9AA7C2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CloudTorrentApp() }
    }
}

private enum class AppTab { HOME, DOWNLOADS, DRIVE, SETTINGS }

@Composable
private fun CloudTorrentApp() {
    var selectedTab by remember { mutableStateOf(AppTab.HOME) }
    var magnet by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Background,
            surface = Surface,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Background,
            bottomBar = {
                NavigationBar(containerColor = Surface) {
                    NavigationBarItem(
                        selected = selectedTab == AppTab.HOME,
                        onClick = { selectedTab = AppTab.HOME },
                        icon = { Icon(Icons.Default.Cloud, null) },
                        label = { Text("Home") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == AppTab.DOWNLOADS,
                        onClick = { selectedTab = AppTab.DOWNLOADS },
                        icon = { Icon(Icons.Default.Download, null) },
                        label = { Text("Downloads") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == AppTab.DRIVE,
                        onClick = { selectedTab = AppTab.DRIVE },
                        icon = { Icon(Icons.Default.Folder, null) },
                        label = { Text("Drive") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == AppTab.SETTINGS,
                        onClick = { selectedTab = AppTab.SETTINGS },
                        icon = { Icon(Icons.Default.Settings, null) },
                        label = { Text("Settings") }
                    )
                }
            }
        ) { padding ->
            when (selectedTab) {
                AppTab.HOME -> HomeScreen(
                    modifier = Modifier.padding(padding),
                    onAddTorrent = { showAddDialog = true },
                    onOpenDownloads = { selectedTab = AppTab.DOWNLOADS }
                )
                AppTab.DOWNLOADS -> DownloadsScreen(Modifier.padding(padding))
                AppTab.DRIVE -> DriveScreen(Modifier.padding(padding))
                AppTab.SETTINGS -> SettingsScreen(Modifier.padding(padding))
            }
        }

        if (showAddDialog) {
            AlertDialog(
                onDismissRequest = { showAddDialog = false },
                containerColor = Surface,
                title = { Text("Add torrent") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Paste a magnet link or torrent URL.", color = Muted)
                        OutlinedTextField(
                            value = magnet,
                            onValueChange = { magnet = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("magnet:?xt=urn:btih:...") },
                            minLines = 3
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        // Backend integration is added in the next implementation phase.
                        showAddDialog = false
                    }) { Text("Add", color = Accent) }
                },
                dismissButton = {
                    TextButton(onClick = { showAddDialog = false }) {
                        Text("Cancel", color = Muted)
                    }
                }
            )
        }
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier = Modifier,
    onAddTorrent: () -> Unit,
    onOpenDownloads: () -> Unit
) {
    Column(
        modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("CLOUDTORRENT", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("Your cloud library", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            }
            Surface(color = Color(0xFF173A32), shape = RoundedCornerShape(50)) {
                Text("●  CLOUD", color = Color(0xFF66D6A5), modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 11.sp)
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Default.Link, contentDescription = null, tint = Accent)
                Text("Add a torrent", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text("Send a magnet link to your cloud server. Your phone does not need to download the torrent data.", color = Muted, fontSize = 13.sp)
                Button(onClick = onAddTorrent, modifier = Modifier.fillMaxWidth()) {
                    Text("Add magnet link")
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Overview", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("View all", color = Accent, modifier = Modifier.clickable { onOpenDownloads() })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Active", "0", Modifier.weight(1f))
            StatCard("Completed", "0", Modifier.weight(1f))
        }
        Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PlayCircle, null, tint = Accent, modifier = Modifier.size(34.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Ready to stream", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Completed Drive uploads will appear in your library.", color = Muted, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Text("CloudTorrent • Initial development build", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Muted, fontSize = 12.sp)
            Text(value, color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun DownloadsScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Downloads", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        EmptyState("No downloads yet", "Add a magnet link to create your first cloud download.")
    }
}

@Composable
private fun DriveScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Google Drive", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        EmptyState("Your library is empty", "Connect Google Drive to see uploaded files and stream supported videos.")
    }
}

@Composable
private fun SettingsScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Account", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Google Drive connection will be configured during backend integration.", color = Muted, fontSize = 13.sp)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Server", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Not configured", color = Color(0xFFFFC46B), fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun EmptyState(title: String, description: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
        Column(
            Modifier.fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(Icons.Default.Folder, null, tint = Muted, modifier = Modifier.size(38.dp))
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(description, color = Muted, fontSize = 12.sp)
        }
    }
}
