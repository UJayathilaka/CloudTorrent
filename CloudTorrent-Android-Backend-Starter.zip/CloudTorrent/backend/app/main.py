from fastapi import FastAPI
from pydantic import BaseModel, Field

app = FastAPI(title="CloudTorrent API", version="0.1.0")

class AddTorrentRequest(BaseModel):
    magnet_uri: str = Field(min_length=10, max_length=8192)

@app.get("/health")
def health():
    return {"status": "ok", "service": "cloudtorrent-api"}

@app.post("/torrents")
def add_torrent(payload: AddTorrentRequest):
    # TODO: Validate the magnet URI, authenticate the app user,
    # then submit it to the qBittorrent Web API.
    # Never expose the qBittorrent Web UI directly to the public internet.
    return {
        "status": "not_configured",
        "message": "Torrent engine integration is not configured yet."
    }

@app.get("/torrents")
def list_torrents():
    # TODO: Return jobs belonging to the authenticated user.
    return {"items": []}

@app.get("/drive/files")
def list_drive_files():
    # TODO: Use the authenticated user's Google OAuth credentials
    # and list only files accessible to the app.
    return {"items": []}
