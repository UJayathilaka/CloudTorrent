# CloudTorrent — Development Starter

This repository is the initial Android + backend foundation for CloudTorrent.

## Current status

**Milestone 1: Android UI foundation and backend API skeleton.**

Included:
- Kotlin + Jetpack Compose dark UI
- Home, Downloads, Drive, and Settings screens
- Add-magnet dialog (UI only; not connected yet)
- FastAPI health endpoint and API placeholders
- GitHub Actions workflow for building a debug APK

Not implemented yet:
- qBittorrent integration and persistent download worker
- Google OAuth consent configuration and token handling
- Google Drive resumable upload
- Authenticated file listing and HTTP Range streaming
- ExoPlayer connection to the streaming endpoint
- Production authentication, rate limiting, and deployment hardening

Do not expose qBittorrent's Web UI or API directly to the public internet.
Only download and share content you are legally authorized to access.

## Build Android app

Requirements:
- Android Studio with Android SDK 35
- JDK 17
- Gradle 8.9-compatible environment

Open this folder in Android Studio and sync Gradle, then run:
`gradle :app:assembleDebug`

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

A GitHub Actions workflow is included at `.github/workflows/android-apk.yml`.
Push the project to a GitHub repository and run the workflow to obtain a debug APK artifact.

## Backend local development

From `backend/`:
`python -m venv .venv`
Activate the environment, then:
`pip install -r requirements.txt`
`uvicorn app.main:app --reload`

Health check:
`GET http://127.0.0.1:8000/health`

## Important architecture note

Google Drive is the permanent storage. The cloud VM still needs temporary disk space for torrent downloading and upload staging. A free cloud VM is not guaranteed to be continuously available, and free-tier policies/quotas can change.
